require 'foreman_extensions/engine'

module ForemanExtensions
end

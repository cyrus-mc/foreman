# Matches foreman_extensions.gemspec
_('TODO: Description of ForemanExtensions.')

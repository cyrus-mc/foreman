FactoryGirl.define do
  factory :host do
    name 'foreman_extensions'
  end
end
